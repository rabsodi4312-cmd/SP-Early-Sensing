# 보고서 규칙

`leak-detection-report-agent`가 생성하는 분석 보고서(및 `leak-review-agent`의 검토 그룹 A)에
적용되는 구조/형식 규칙. (출처: `workflow.md` 검토 항목 A1, A4, A5)

- 섹션 완전성: `reference/example.html`과 동일하게 `class="slide"` 11개 섹션 구성을 갖춰야 한다.
- 레이아웃 재사용: `reference/example.html`과 동일한 CSS 클래스 체계를 사용한다 (임의 변경 금지).
- Executive Summary: 핵심 통계 3종 + 전주 대비 비교표 + 결론(3줄 이하, 각 1문장)을 포함해야 한다.
