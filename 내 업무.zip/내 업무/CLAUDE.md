# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## WHY
온양EHS팀의 "압력모니터링 기반 미세Leak 감지 연구" 업무를, 검증까지 포함한 Sub Agent 파이프라인으로
자동화해 상사에게 보고 가능한 분석 보고서와 대시보드를 산출하는 것이 이 Agent 팀의 최종 목표다.

## WHAT
- 입력자료: `data/압력계목록.csv`, `data/압력모니터링_측정데이터.csv`, `data/압력모니터링_미세Leak_더미데이터_20개소.xlsx` (수정 금지, 항상 이 데이터가 근거)
- Sub Agent 3개 (지시서: `.claude/agents/`)
  1. `leak-detection-report-agent` — 데이터 분석 → 분석 보고서 HTML 생성
  2. `leak-dashboard-monitoring-agent` — 데이터 분석 → 조기 센싱 대시보드 + (경보 시) 알림 초안 생성
  3. `leak-review-agent` — 1·2의 산출물을 항목별 PASS/FAIL로 검증만 수행 (수정·재실행 없음)
- 최종 결과물 위치: `output/` (보고서 HTML, 대시보드 HTML, `leak-review-result.md`)

## HOW
- 확정 Workflow와 판정 임계값, FAIL 시 재실행 규칙은 `workflow.md`가 최신 진실 소스이며 항상 이 문서를 우선 확인한다.
- Sub Agent 1·2는 `data/`를 공통 입력으로 독립 병렬 실행되고, 3(leak-review-agent)이 이어서 검증한다.
- 각 Sub Agent는 하나의 역할만 위임받으며, 세부 수행 방법은 각자의 지시서(`.claude/agents/*.md`)를 따른다.
- 아직 확정되지 않은 다음 단계는 추가하지 않고, 입력이 비어있거나 충돌할 때만 사용자에게 질문한다.
- Sub Agent나 파이프라인을 바꾸면 `workflow.md`를 함께 갱신한다.
- 팀 전체 공통 규칙(보고서/데이터검증/보안)은 `.claude/rules/`에 있으며 항상 지켜야 한다.
