@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo ============================================================
echo  압력모니터링 기반 미세Leak 감지 연구 - Multi-Agent Workflow 실행
echo ============================================================
echo.

claude -p "이 폴더의 workflow.md에 정의된 확정 Workflow대로, Multi-Agent 팀(leak-detection-report-agent, leak-dashboard-monitoring-agent, leak-review-agent)을 사용해 업무를 처음부터 끝까지 실행하고 최종 산출물까지 만들어라. Sub Agent 1(leak-detection-report-agent)과 Sub Agent 2(leak-dashboard-monitoring-agent)는 data/ 원본을 공통 입력으로 독립적으로 병렬 실행하고, 두 산출물이 모두 나오면 Sub Agent 3(leak-review-agent)로 검증하라. FAIL이 있으면 workflow.md의 'FAIL 시 수정 흐름' 규칙(그룹별 최대 1회 재실행 후 재검토, 또 FAIL이면 반복 중단하고 사람 확인으로 이관)을 그대로 따르라. CLAUDE.md와 .claude/rules/의 공통 규칙을 항상 지키고, 최종 산출물은 output/ 폴더(보고서 HTML, 대시보드 HTML, leak-review-result.md)에 저장하라." --dangerously-skip-permissions

echo.
echo ============================================================
echo  실행 완료. output 폴더를 확인하세요.
echo ============================================================
pause
